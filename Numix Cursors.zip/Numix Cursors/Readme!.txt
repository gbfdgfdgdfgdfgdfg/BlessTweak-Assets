
 Click on the file install.inf right mouse button, the shortcut menu to choose - to install

 -------------------------------------------------------------------------------------------

 http://alexgal23.deviantart.com/